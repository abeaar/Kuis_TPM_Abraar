package com.example.kuistpmab

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
